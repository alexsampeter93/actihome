# Handoff: ActiHome — Rediseño de interfaz (catálogo estacional + pantallas)

## Overview
Rediseño completo de la interfaz de **ActiHome**, una aplicación de alojamientos turísticos con dos roles (ADMIN / CUSTOMER). Cubre el catálogo de alojamientos y todas las pantallas de flujo: detalle, reserva, mis reservas, reseñas (listado y detalle), publicar reseña, login, registro, subir/editar alojamiento, perfil e **intercambio de alojamientos**.

La dirección visual es **editorial premium tipo revista de viajes** (nada de estética "plantilla SaaS/IA"): tipografía serif protagonista, mucho aire, bordes finos en lugar de sombras difusas, y un **sistema de color estacional** (primavera / verano / otoño / invierno) que reambienta toda la pantalla, incluida una capa de partículas (hojas, nieve, lluvia, sol).

## About the Design Files
Los archivos de este paquete son **referencias de diseño creadas en HTML** — prototipos que muestran el aspecto y el comportamiento buscados, **no código de producción para copiar tal cual**. La tarea es **recrear estos diseños en el entorno del código de ActiHome** usando sus patrones y librerías establecidos.

> ActiHome es actualmente una app de escritorio en **Java Swing**. Estas maquetas web son la referencia visual/interactiva. En Swing, la mayoría se traslada con layouts (`GridBagLayout`, `MigLayout`) y `JPanel` con `paintComponent` personalizado; la capa de partículas estacional se puede hacer con un `JPanel` transparente encima + `javax.swing.Timer` repintando. Si en su lugar se migra a web (React/Vue/etc.), recréelo con la librería de componentes de ese stack. En cualquier caso, **no se envía el HTML directamente**.

`ActiHome Mockups.dc.html` es el archivo de diseño (ábrelo junto a `support.js` para verlo interactivo). `ActiHome Mockups (standalone).html` es la misma referencia empaquetada en un único archivo, para abrir a doble clic sin depender de internet ni de `support.js`.

## Fidelity
**Alta fidelidad (hi-fi).** Colores, tipografía, espaciados e interacciones son finales. Recrear la UI de forma fiel. Las fotos van como **placeholders** (rectángulos con textura/tinte y una etiqueta); se sustituyen por imágenes reales de cada alojamiento.

---

## Sistema de color estacional (núcleo del diseño)
Toda la UI se pinta a partir de una paleta activa según la estación. Por defecto arranca en la **estación actual** y el usuario puede cambiarla cuando quiera desde el selector del catálogo. Cada pantalla lee la misma paleta (implementado con variables CSS `--acc`, `--bg`, `--hdr`, `--txt`, `--mut`, `--img`, `--imgTint`).

| Token | Rol | Primavera | Verano | Otoño | Invierno |
|---|---|---|---|---|---|
| `acc` | Acento (botones, activos, precios destacados) | `#4E7A3E` | `#C0870F` | `#A9701F` | `#5A5B86` |
| `bg` | Fondo de página | `#F3F1E6` | `#FBF3E1` | `#F4EDE0` | `#ECECF1` |
| `hdr` | Barra de navegación (oscura) | `#2A3A20` | `#33291A` | `#38291A` | `#242539` |
| `txt` | Texto principal | `#232A1B` | `#2B2513` | `#29200F` | `#22233A` |
| `mut` | Texto/hairlines secundarios | `#7D8570` | `#8C7F60` | `#8A7D66` | `#7C7C93` |
| `img` | Color base del placeholder de foto | `#E4E6D5` | `#F2E6C2` | `#EADFC9` | `#DDDCE6` |
| `imgTint` | Tinte translúcido sobre la foto | `rgba(120,150,80,.16)` | `rgba(245,195,70,.18)` | `rgba(170,110,30,.18)` | `rgba(96,98,150,.15)` |
| Etiqueta | (label de la estación) | "Estancias de primavera — Brotes, campo verde y días largos" | "Estancias de verano — Sol alto, luz dorada y sombra fresca" | "Estancias de otoño — Hojas, viñedos y tardes doradas" | "Estancias de invierno — Nieve, chimenea y luz de dusk" |

Sobre las superficies (fichas, formularios) se usa blanco `#FFFFFF` con hairlines `rgba(0,0,0,.12)` y bordes de campo `rgba(0,0,0,.2)`. El texto sobre `acc` es blanco `#FFFFFF`.

**Verano** es intencionalmente un dorado-sol cálido (no azul mar): el acento `#C0870F` sobre fondo crema evoca luz de verano, no la paleta de marca de ningún asistente de IA.

### Capa de ambiente estacional (partículas)
Overlay `<canvas>` a pantalla completa sobre el catálogo, `pointer-events:none` (no bloquea clics), animado con `requestAnimationFrame`. Cambia al instante al cambiar de estación:
- **Primavera → lluvia**: líneas finas diagonales `rgba(150,180,205,.4)`, caída rápida, ligero ángulo.
- **Verano → sol marcado**: resplandor radial cálido desde la esquina superior derecha (`rgba(255,214,96,…)`), 6 haces de luz diagonales que titilan, disco solar visible (halo + núcleo), y motas doradas flotando con parpadeo. Es el efecto más marcado de los cuatro — debe notarse claramente, no ser un tinte sutil.
- **Otoño → hojas**: elipses en tonos `#B5651D/#C77A3F/#9A6324/#8a4b2a/#d19a4a` cayendo con rotación y vaivén.
- **Invierno → nieve**: círculos blancos `rgba(255,255,255,.9)` a la deriva.

Densidad ≈ 90 partículas (22 en verano, donde el efecto principal es la luz, no las motas). Es un detalle de acabado, opcional; se puede simplificar a "una ráfaga al cambiar de estación y luego parar".

---

## Screens / Views
Cada pantalla comparte una **barra de navegación** oscura (`hdr`): wordmark "ActiHome" en Spectral serif, versalitas con tracking (Catálogo · Reservas · Reseñas), y a la derecha el avatar circular (iniciales) + usuario. Chip "ADMIN" cuando aplica.

### 1) Catálogo (ShowHousingsFrame) — pantalla `1H` (versión final)
- **Propósito**: explorar y filtrar alojamientos; punto de entrada tras login.
- **Layout (de arriba a abajo)**:
  1. **Cabecera** (fondo `hdr`, texto `bg`).
  2. **Hero**: a la izquierda label estacional (`acc`) + título Spectral 46px "Elige dónde quieres *despertar*"; a la derecha **selector de estación** (label "Viajar en" + 4 pestañas Primavera/Verano/Otoño/Invierno) y, debajo, **3 cifras editoriales**: "en catálogo" / "disponibles" / "media" (calculadas en vivo sobre el total de alojamientos, no sobre el resultado filtrado).
  3. **Fila de tipo**: label "Tipo" + chips Todos/Casa/Apartamento/Villa/Cabaña (selección única; activo = fondo `txt`, texto blanco) + campo numérico "Mín. habitaciones".
  4. **Toolbar** (entre 2 hairlines): buscador con icono lupa (filtra por nombre/ubicación/tipo en vivo) · contador "N estancias" · **conmutador de vista** Lista / Cuadrícula (segmentado; activo con fondo `acc`).
  5. **Fila de filtros**: "Filtrar" + chips toggle de amenidades (Piscina, Wifi, TV, Parking, Aire ac., Desayuno, Mascotas) — activo = fondo `acc`/texto blanco, inactivo = borde `rgba(0,0,0,.2)`/texto `mut`, `border-radius:50px`. A la derecha "Ordenar" + 3 opciones (Mejor valorados / Precio · menor / Precio · mayor), activa subrayada en `acc`.
  6. **Contenido** en dos vistas (ver abajo).
  7. **Capa de partículas** (canvas, ver arriba).
  8. **FAB de admin**: esquina inferior derecha, etiqueta "Registrar alojamiento · admin" + botón circular `+` (fondo `hdr`, sin degradado ni animación de giro) — visible solo para ADMIN.
- **Vista Lista**: filas `grid-template-columns:46% 1fr; gap:44px`, separadas por hairline. Izquierda: foto (alto 290px, `img` + velo `imgTint`, etiqueta de tipo arriba-izq sobre `rgba(0,0,0,.42)`, estado disponible/reservada abajo-izq). Derecha: fila "Nº 01 —— coordenadas · ubicación" (mono, `acc` para el nº), título Spectral 32px, línea de meta (nº serif + barra fina `acc` sobre `rgba(0,0,0,.12)` + "N reseñas" + habitaciones + **propietario**; usa `flex-wrap:wrap` para no desbordar en anchos estrechos), línea "Pensión" (comidas incluidas en `txt`, no incluidas tachadas), chips de amenidades (borde fino, `border-radius:50px`), y pie: precio Spectral 30px + acciones "Intercambiar ⇄" (`acc`) y "Ver estancia →" (subrayado `txt`).
- **Vista Cuadrícula**: `repeat(3,1fr); gap:30px`. Tarjeta: foto cuadrada (`aspect-ratio:1/1`) con etiqueta tipo, disco de puntuación (círculo 30px `acc`) arriba-der, estado abajo-izq; debajo: "Nº · ubicación" (mono), título Spectral 21px, "N reseñas · habitaciones", pie con precio + "Ver →".
- **Filtros (todos funcionales y combinables entre sí)**:
  - **Tipo**: selección única.
  - **Mín. habitaciones**: numérico, `roomsNum >= valor`.
  - **Amenidades**: multi-toggle, lógica Y.
  - **Buscador**: nombre + ubicación + tipo, en vivo.
  - **Ordenar**: por puntuación o precio.
- **Datos de ejemplo (6 alojamientos)**:
  1. Casa Rural El Pinar — Casa — #10001 — Sierra Nevada, Granada — 37.09°N — 3 hab — 75,00 € — 4,2 (14) — disponible — propietario — incluye Desayuno, Cena — amenidades: wifi, tv, parking, desayuno, mascotas.
  2. Apartamento Playa Centro — Apartamento — #10002 — Málaga — 36.72°N — 2 hab — 95,00 € — 4,8 (31) — disponible — propietario2 — incluye Desayuno — wifi, tv, ac, piscina, desayuno.
  3. Villa Mediterráneo — Villa — #10003 — Ibiza — 38.90°N — 5 hab — 320,00 € — 4,5 (8) — **reservada** — propietario — incluye Desayuno, Almuerzo, Cena — piscina, wifi, tv, parking, ac, desayuno.
  4. Cabaña del Bosque — Cabaña — #10004 — Picos de Europa, Asturias — 43.19°N — 1 hab — 48,00 € — 3,4 (5) — disponible — propietario3 — sin comidas incluidas — parking, mascotas.
  5. Loft Barrio Gótico — Apartamento — #10005 — Barcelona — 41.38°N — 2 hab — 130,00 € — 4,9 (47) — disponible — propietario2 — incluye Desayuno — wifi, tv, ac, desayuno.
  6. Casa Adosada Las Palmas — Casa — #10006 — Gran Canaria — 28.12°N — 4 hab — 110,00 € — 4,1 (19) — disponible — propietario4 — incluye Desayuno, Almuerzo — piscina, wifi, tv, parking, ac, desayuno.

### 2) Detalle de alojamiento (HousingDetailsFrame) — `1I`
- **Propósito**: ver un alojamiento y actuar (reservar / intercambiar / ver reseñas / actualizar).
- **Layout**: breadcrumb "Catálogo › Nombre". Dos columnas 1fr/1fr. Izq: galería (foto grande 340px + 3 miniaturas, la última con "+6"). Der: código+coordenadas (mono), título Spectral 36px, puntuación (nº + barra + reseñas), descripción, mini-grid 2×2 (Habitaciones / Disponible / Pensión / Titular), precio Spectral 34px, y botonera.
- **Botones según rol (fiel al código `HousingDetailsFrame`)**:
  - **Reservar** — solo CUSTOMER.
  - **Intercambiar ⇄** y **Actualizar alojamiento** — solo ADMIN que sea **propietario** del alojamiento.
  - **Ver reseñas** — siempre.

### 3) Reservar alojamiento (1J)
- **Campos (fiel a `ReserveHousingFrame`)**: Fecha check-in, Fecha check-out (ambos date pickers `dd/MM/yyyy`), Tarjeta de crédito.
- **Resumen**: precio/noche × nº noches = **Total** (Spectral 26px). Ej.: 75,00 € × 4 = 300,00 €.
- Botón primario "Confirmar reserva" + Cancelar.

### 4) Mis reservas (ShowMyReservationsFrame) — `1K`
Lista de filas `96px 1fr auto`: miniatura | código `#R-…` + nombre serif + fechas/noches/ubicación | total serif + estado. Estados: **Check-in pendiente** (borde `acc`), **✓ Check-in realizado** (`mut`), **Completada** (atenuada). Mapea `reservationCode`, `checkIn/checkOut`, `totalPrice`, `checkedIn`.

### 5) Reseñas del alojamiento (ShowReviewsFrame) — `1L`
Cabecera: "Reseñas · <alojamiento>" + nota media grande serif 40px en `acc` + nº reseñas. Lista separada por hairlines: título serif 20px + nota total en `acc`; "por <autor> · fecha"; extracto del cuerpo; fila de sub-notas en versalita (**Ubicación · Servicio · Wifi · Comida · Limpieza** con su valor); "Ver reseña →".

### 6) Detalle de reseña (ReviewDetailsFrame) — `1M`
Título serif 28px + disco de nota **Total** (círculo `acc` 64px). "por <autor> · fecha". Cuerpo. **5 barras de sub-notas** (etiqueta versalita | barra rellena a valor/5 en `acc` | valor serif): ubicación, servicio, wifi, comida, limpieza. Nota: "Actualizar reseña" solo para el autor.

### 7) Publicar reseña (PublishReviewFrame) — `1N`
Campos **Título** y **Cuerpo** (textarea). **5 valoraciones** (ubicación, servicio, wifi, comida, limpieza) como fila de 5 estrellas seleccionables (0–5, paso 0,1 en el modelo original; en la maqueta se muestran estrellas). Nota "la calificación total se calcula automáticamente". Botón **Publicar reseña** (`acc`).

### 8) Login (LoginFrame) — `1O`
Panel superior con `hdr` + tinte de estación y claim serif. Campos **Nombre de usuario** y **Contraseña**. Botón **Entrar** (`acc`). Enlace a registro.

### 9) Registro (SignUpFrame) — `1P`
Rejilla 2 columnas: usuario, contraseña, nombre, apellido, localidad, teléfono, correo, **fecha de nacimiento** (campo fecha). **Rol** como segmentado **Customer / Admin** (enum `RoleType`). Botón **Registrarse** + enlace a login.

### 10) Subir / editar alojamiento (UploadHousingFrame / UpdateHousingFrame) — `1Q` (admin)
Rejilla: **Código** (mono), **Tipo** (select), **Nº de habitaciones**, **Precio por noche**, **Ubicación**, **Descripción** (textarea), y **Comidas incluidas** como checkboxes (Desayuno / Comida / Cena; marcado = cuadrado relleno `acc` con check). Botón **Registrar**. (En "editar", el código no es editable y los campos llegan precargados.) Accesible también desde el **FAB** del catálogo.

### 11) Perfil (UpdateProfileFrame) — `1R`
Cabecera con avatar `acc` 88px + nombre serif + chip de rol + "@usuario · localidad" + botón **Editar perfil**. Fila de 3 estadísticas (alojamientos publicados / reservas / valoración media). Rejilla de datos: nombre completo, localidad, teléfono, correo, fecha de nacimiento, rol. Enlace "Cambiar contraseña →" (ChangePasswordFrame).

### 12) Intercambio de alojamientos (TradeHousingsFrame) — `1G`
Título centrado + explicación. Composición **Tu alojamiento ⇄ Alojamiento a recibir**: panel izquierdo con una de tus viviendas; glifo central ⇄ en círculo `acc`; panel derecho con la vivienda encontrada por **código**. Campo "Código del alojamiento a intercambiar" (mono, con botón Buscar). Franja de confirmación verde: ambos deben estar **disponibles**; al confirmar se **permuta la titularidad**. Botón **Confirmar intercambio ⇄**. (Lógica `HousingService.tradeHousings(ownerId, ownersHousingId, housingToTradeCode)`: valida existencia y disponibilidad, si no lanza `AlreadyReservedException`, y cambia `owner` de ambas.)

---

## Interactions & Behavior
- **Selector de estación**: cambia la paleta (variables CSS) y el efecto de partículas al instante; transición de fondo 0.4s ease. Default = estación actual.
- **Buscador**: filtra el catálogo en vivo por nombre + ubicación + tipo (case-insensitive).
- **Conmutador de vista**: Lista ↔ Cuadrícula (el estado activo va con fondo `acc`).
- **Filtro de tipo**: selección única entre Todos/Casa/Apartamento/Villa/Cabaña.
- **Filtro de mín. habitaciones**: numérico, `>=`.
- **Filtros de amenidades**: toggles, combinación Y; el contador "N estancias" refleja el resultado.
- **Ordenar**: por puntuación (desc) o precio (asc/desc).
- **FAB admin**: acceso directo a "Registrar alojamiento" (equivalente a `UploadHousingFrame`), visible solo para ADMIN.
- **Partículas**: canvas a rAF, `pointer-events:none`.
- **Visibilidad por rol**: acciones Reservar (CUSTOMER) vs Intercambiar/Actualizar/FAB de registrar (ADMIN propietario) según `HousingDetailsFrame`.
- **Transiciones sutiles**: cambios de color de chips/pestañas ~0.2–0.25s.

## State Management
Estado del catálogo: `season` ('primavera'|'verano'|'otono'|'invierno'), `view` ('list'|'grid'), `query` (string), `sort` ('score'|'priceAsc'|'priceDesc'), `amenities` (array de claves activas), `type` ('Todos'|'Casa'|'Apartamento'|'Villa'|'Cabaña'), `minRooms` (número). El catálogo mostrado se deriva: filtrar por query + amenidades + tipo + minRooms → ordenar por `sort`. Cada `housing` de ejemplo lleva: `amen` (['pool','wifi','tv','parking','ac','breakfast','pets'] subset), `roomsNum`, `scoreNum`, `priceNum`. Las cifras del hero (en catálogo / disponibles / media) se calculan sobre el total de `housings`, no sobre el resultado filtrado.

## Design Tokens
- **Colores**: ver tabla de paletas + neutros (`#FFFFFF`, hairline `rgba(0,0,0,.12)`, borde de campo `rgba(0,0,0,.2)`, texto sobre acento `#FFFFFF`).
- **Tipografía**: **Spectral** (serif) para display, títulos, precios, cifras y etiquetas en cursiva; **Manrope** (sans) para UI y cuerpo. Google Fonts. Pesos: Spectral 400/500/600 (+ italic), Manrope 400–800.
- **Escala tipográfica**: hero 46–52px · títulos de pantalla 28–36px · nombre de ficha 21–32px · cuerpo 14–15px · precio 22–34px · etiquetas 11–12px versalita (letter-spacing .12–.24em).
- **Radios**: 2–4px en superficies (estética editorial "afilada"); pills 50px (chips/amenidades); círculos (avatares, disco de puntuación, FAB).
- **Sombra de ventana** (solo para el mockup flotante): `0 40px 90px rgba(0,0,0,.5)` — en la app real no hace falta.
- **Espaciado**: paddings frecuentes 16/20/34/40/44/48px; gaps 10–60px.

## Data model (entidades reales de ActiHome)
- **Housing**: housingCode, type, numberOfRooms, pricePerNight, description, breakfast, lunch, dinner, available, location, owner(User), score.
- **Reservation**: reservationCode, checkIn, checkOut, paymentMethod, reservationDate, totalPrice, checkedIn, customer(User), housing(Housing).
- **Review**: title, body, locationScore, serviceScore, wifiScore, foodScore, cleaningScore, totalScore, publicationDate, author(User), housing(Housing).
- **User**: username, password, name, surname, locality, phoneNumber, email, birthDate, role (ADMIN | CUSTOMER).
- **Intercambio**: `tradeHousings(ownerId, ownersHousingId, housingToTradeCode)` — permuta `owner` de dos viviendas disponibles.

> Nota: las "amenidades" del catálogo (piscina, wifi, TV, parking, aire, mascotas) **no existen aún** en la entidad `Housing` (solo hay breakfast/lunch/dinner). Si se quieren los filtros completos, hay que añadir esos campos booleanos a `Housing` (y a los formularios de subir/editar). "Desayuno" sí mapea a `breakfast`.

## Assets
- **Fuentes**: Spectral + Manrope (Google Fonts).
- **Iconos**: SVG inline sencillos (lupa, calendario, check, chevrons, líneas/rejilla para el conmutador de vista, +). Sustituibles por el set de iconos del stack destino.
- **Fotos**: placeholders — sustituir por imágenes reales de cada alojamiento.
- **Sin logotipos de terceros, emojis decorativos ni degradados de marca.**

## Files
- `ActiHome Mockups.dc.html` — prototipo de todas las pantallas (referencia principal, requiere `support.js` al lado y conexión a internet para las fuentes/runtime).
- `support.js` — runtime del prototipo (solo para poder abrir/ver el `.dc.html`; no forma parte del diseño a implementar).
- `ActiHome Mockups (standalone).html` — el mismo prototipo empaquetado en un único archivo autocontenido; ábrelo a doble clic sin depender de nada más, útil para enseñarlo o revisarlo offline.
